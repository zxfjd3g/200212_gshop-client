<template>
  <div>
    <h2 class="t3 t2">Test3</h2>
    <Test4></Test4>
  </div>
</template>

<script>
import Test4 from './Test4'
export default {
  name: 'Test3',
  components: {
    Test4,
  }
}
</script>

<style>

</style>
