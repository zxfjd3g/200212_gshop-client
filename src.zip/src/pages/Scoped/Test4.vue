<template>
  <div>
    <h2 class="t2">Test4</h2>
    <h2 class="t4">Test4</h2>
  </div>
</template>

<script>
export default {
  name: 'Test4',
}
</script>

<style>

</style>
