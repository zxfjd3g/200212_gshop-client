<template>
  <div class="t2">Test5</div>
</template>

<script>
import Test6 from './Test6'
export default {
  name: 'Test5',
  components: {
    Test6
  }
}
</script>

<style>

</style>
