<template>
  <div>
    <h2>
      <span>Test6</span>
    </h2>
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'Test6',
}
</script>

<style>

</style>
